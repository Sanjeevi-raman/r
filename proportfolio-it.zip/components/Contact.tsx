
import React, { useState } from 'react';
import { Message } from '../types';

interface ContactProps {
  info: any;
}

const Contact: React.FC<ContactProps> = ({ info }) => {
  const [formState, setFormState] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');

    // Simulate sending but also PERSIST the data to the admin "inbox" in localStorage
    setTimeout(() => {
      const existingMessagesRaw = localStorage.getItem('portfolio_messages');
      const messages: Message[] = existingMessagesRaw ? JSON.parse(existingMessagesRaw) : [];
      
      const newMessage: Message = {
        id: Date.now().toString(),
        name: formState.name,
        email: formState.email,
        message: formState.message,
        timestamp: new Date().toISOString()
      };

      messages.unshift(newMessage);
      localStorage.setItem('portfolio_messages', JSON.stringify(messages));

      setStatus('success');
      setFormState({ name: '', email: '', message: '' });
      setTimeout(() => setStatus('idle'), 3000);
    }, 1500);
  };

  return (
    <div className="py-12">
      <div className="grid lg:grid-cols-2 gap-20 items-center">
        <div>
          <h2 className="text-5xl font-bold mb-8 text-stone-100 tracking-tighter">Inquiries</h2>
          <p className="text-stone-400 text-lg mb-10 leading-relaxed font-light">
            I'm currently considering select opportunities. If you have a project or a position that aligns with my expertise, let's start a conversation.
          </p>
          <div className="space-y-8">
            <div className="flex items-center gap-6 group">
              <div className="w-14 h-14 rounded-2xl bg-stone-900 border border-stone-800 flex items-center justify-center text-stone-100 text-xl group-hover:bg-stone-100 group-hover:text-stone-950 transition-all">
                <i className="fas fa-envelope"></i>
              </div>
              <div>
                <p className="text-stone-600 text-[10px] uppercase font-bold tracking-widest mb-1">Electronic Mail</p>
                <a href={`mailto:${info.email}`} className="text-stone-100 font-medium hover:text-stone-400 transition-colors">
                  {info.email}
                </a>
              </div>
            </div>
            <div className="flex items-center gap-6 group">
              <div className="w-14 h-14 rounded-2xl bg-stone-900 border border-stone-800 flex items-center justify-center text-stone-100 text-xl group-hover:bg-stone-100 group-hover:text-stone-950 transition-all">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <div>
                <p className="text-stone-600 text-[10px] uppercase font-bold tracking-widest mb-1">Base of Operations</p>
                <p className="text-stone-100 font-medium">{info.location}</p>
              </div>
            </div>
          </div>
        </div>
        <div className="p-12 bg-stone-900 rounded-[3rem] border border-stone-800 shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid sm:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-stone-500 text-[10px] uppercase font-bold tracking-widest ml-1">Full Name</label>
                <input type="text" value={formState.name} onChange={(e) => setFormState({...formState, name: e.target.value})} required className="w-full bg-stone-950 border border-stone-800 rounded-2xl px-6 py-4 text-stone-100 focus:outline-none focus:bg-stone-900 transition-all font-light" placeholder="Jane Doe" />
              </div>
              <div className="space-y-3">
                <label className="text-stone-500 text-[10px] uppercase font-bold tracking-widest ml-1">Email Address</label>
                <input type="email" value={formState.email} onChange={(e) => setFormState({...formState, email: e.target.value})} required className="w-full bg-stone-950 border border-stone-800 rounded-2xl px-6 py-4 text-stone-100 focus:outline-none focus:bg-stone-900 transition-all font-light" placeholder="jane@company.com" />
              </div>
            </div>
            <div className="space-y-3">
              <label className="text-stone-500 text-[10px] uppercase font-bold tracking-widest ml-1">Your Message</label>
              <textarea rows={4} value={formState.message} onChange={(e) => setFormState({...formState, message: e.target.value})} required className="w-full bg-stone-950 border border-stone-800 rounded-2xl px-6 py-4 text-stone-100 focus:outline-none focus:bg-stone-900 transition-all resize-none font-light" placeholder="Briefly describe your inquiry..." />
            </div>
            <button type="submit" disabled={status !== 'idle'} className="w-full py-5 bg-stone-100 hover:bg-stone-200 disabled:bg-stone-800 text-stone-950 font-bold rounded-2xl transition-all flex items-center justify-center gap-3 uppercase tracking-widest text-xs shadow-lg shadow-black/30">
              {status === 'sending' ? <><i className="fas fa-circle-notch animate-spin"></i>Processing</> : status === 'success' ? <><i className="fas fa-check"></i>Transmission Sent</> : <><i className="fas fa-paper-plane text-[10px]"></i>Submit Inquiry</>}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
