
import React from 'react';
import { Project } from '../types';

interface ProjectsProps {
  projects: Project[];
}

const Projects: React.FC<ProjectsProps> = ({ projects }) => {
  return (
    <div className="py-12">
      <div className="flex flex-col md:flex-row justify-between items-center md:items-end mb-16 gap-6">
        <div className="text-center md:text-left reveal">
          <h2 className="text-4xl font-bold mb-4 text-stone-100 tracking-tight">Portfolio</h2>
          <p className="text-stone-500 font-light">Selected works and collaborative projects.</p>
        </div>
        <a href="#" className="reveal delay-1 flex items-center gap-2 text-stone-100 hover:gap-4 font-semibold text-sm uppercase tracking-widest transition-all">
          View Repository <i className="fas fa-arrow-right text-xs"></i>
        </a>
      </div>
      
      <div className="grid md:grid-cols-2 gap-12">
        {projects.map((project, idx) => (
          <div key={project.id} className={`reveal delay-${idx + 1} group relative bg-stone-900 rounded-[2.5rem] border border-stone-800 hover:border-stone-600 transition-all overflow-hidden shadow-sm transform hover:scale-[1.02]`}>
            <div className="aspect-[16/10] overflow-hidden bg-stone-950">
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000 group-hover:scale-110"
              />
            </div>
            
            <div className="p-10 relative z-10">
              <div className="flex flex-wrap gap-2 mb-6">
                {project.tags.map(tag => (
                  <span key={tag} className="px-3 py-1 bg-stone-800 text-stone-400 text-[10px] font-bold rounded-full uppercase tracking-tighter group-hover:bg-stone-100 group-hover:text-stone-950 transition-colors">
                    {tag}
                  </span>
                ))}
              </div>
              
              <h3 className="text-2xl font-bold text-stone-100 mb-4 group-hover:text-stone-300 transition-colors tracking-tight">
                {project.title}
              </h3>
              
              <p className="text-stone-400 mb-8 leading-relaxed font-light">
                {project.description}
              </p>
              
              <div className="flex items-center justify-between border-t border-stone-800 pt-8">
                <div className="flex items-center gap-4">
                   <div className="flex -space-x-3">
                     {project.team.map((member, i) => (
                       <img 
                        key={i} 
                        src={member.avatar} 
                        title={`${member.name} (${member.role})`}
                        alt={member.name} 
                        className="w-9 h-9 rounded-full border-2 border-stone-900 ring-1 ring-stone-800 shadow-sm transition-transform hover:scale-150 hover:z-20"
                       />
                     ))}
                   </div>
                   <div className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Collective</div>
                </div>
                <div className="flex gap-3">
                  {project.githubUrl && (
                    <a href={project.githubUrl} className="w-10 h-10 bg-stone-800 hover:bg-stone-100 hover:text-stone-950 flex items-center justify-center rounded-full text-stone-300 transition-all transform hover:rotate-[360deg]"><i className="fab fa-github"></i></a>
                  )}
                  {project.demoUrl && (
                    <a href={project.demoUrl} className="w-10 h-10 bg-stone-100 hover:bg-white flex items-center justify-center rounded-full text-stone-950 transition-all transform hover:rotate-[360deg]"><i className="fas fa-external-link-alt text-xs"></i></a>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
