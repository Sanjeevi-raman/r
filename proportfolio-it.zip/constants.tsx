
import { Experience, Project, Certificate, Skill, Friend, UIConfig } from './types';

// Helper to get initial data
const getInitialData = (key: string, defaultValue: any) => {
  const saved = localStorage.getItem(`portfolio_${key}`);
  return saved ? JSON.parse(saved) : defaultValue;
};

export const saveData = (key: string, data: any) => {
  localStorage.setItem(`portfolio_${key}`, JSON.stringify(data));
};

export const UI_CONFIG_DEFAULT: UIConfig = {
  fontFamily: 'Inter',
  fontSizeBase: '16px',
  primaryColor: '#f5f5f4', // stone-100
  backgroundColor: '#0c0a09', // stone-950
  textColor: '#a8a29e', // stone-400
};

export const getUIConfig = (): UIConfig => getInitialData('ui_config', UI_CONFIG_DEFAULT);

export const PERSONAL_INFO_DEFAULT = {
  name: "SANJEEVI RAMAN E",
  title: "Multi-Cloud Learner | Cybersecurity Intern | Competitive Programmer",
  about: "A highly motivated Computer Science undergraduate actively building expertise across Cybersecurity, Cloud Computing (AWS, Azure, GCP), Competitive Programming, AI Innovation, and UI/UX Design. Passionate about solving real-world problems through hands-on internships and hackathons.",
  email: "sanjeevi.raman@example.dev",
  location: "Tamil Nadu, India",
  profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800",
  github: "https://github.com/sanjeeviraman",
  linkedin: "https://linkedin.com/in/sanjeeviraman",
  twitter: "https://twitter.com/sanjeevi_dev",
};

export const getPersonalInfo = () => getInitialData('personal_info', PERSONAL_INFO_DEFAULT);

export const SKILLS_DEFAULT: (Skill & { icon: string })[] = [
  { 
    category: "Cloud Computing", 
    items: ["AWS", "Azure", "Google Cloud", "Cloud Architecture", "Terraform"],
    icon: "devicon-amazonwebservices-plain-wordmark"
  },
  { 
    category: "Cybersecurity", 
    items: ["Kali Linux", "Ethical Hacking", "Metasploit", "OWASP", "Burp Suite"],
    icon: "devicon-linux-plain"
  }
];

export const getSkills = () => getInitialData('skills', SKILLS_DEFAULT);

export const EXPERIENCES_DEFAULT: Experience[] = [
  {
    id: "exp1",
    company: "Skilldunia",
    role: "Cyber Security Intern",
    period: "2023 - Present",
    location: "Remote / Hybrid",
    type: "internship",
    description: [
      "Gaining practical exposure in industrial security practices and vulnerability assessments.",
      "Developing a deep understanding of organizational cybersecurity posture and risk management."
    ]
  }
];

export const getExperiences = () => getInitialData('experiences', EXPERIENCES_DEFAULT);

export const FRIENDS_DEFAULT: Friend[] = [
  {
    id: "f1",
    name: "Alex Johnson",
    role: "Cloud Architect",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400",
    phoneNumber: "+91 98765 43210",
    socials: {
      linkedin: "#",
      github: "#",
      twitter: "#"
    }
  }
];

export const getFriends = () => getInitialData('friends', FRIENDS_DEFAULT);

export const PROJECTS_DEFAULT: Project[] = [
  {
    id: "p1",
    title: "AI Hackathon & Paper Presentation",
    description: "Presented a research paper on AI Innovation at YouthFest 2026.",
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=800",
    tags: ["AI", "Research"],
    team: [{ name: "Sanjeevi", role: "Researcher", avatar: "https://i.pravatar.cc/150?u=s" }]
  }
];

export const getProjects = () => getInitialData('projects', PROJECTS_DEFAULT);

export const CERTIFICATES_DEFAULT: Certificate[] = [
  {
    id: "c1",
    title: "AWS Academy Cloud Foundations",
    issuer: "AWS Academy",
    date: "2023",
    credentialUrl: "#",
    image: "https://images.unsplash.com/photo-1523240715630-3882bb46351d?auto=format&fit=crop&q=80&w=400"
  }
];

export const getCertificates = () => getInitialData('certificates', CERTIFICATES_DEFAULT);
